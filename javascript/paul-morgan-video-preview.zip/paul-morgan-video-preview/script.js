console.log("page loaded...");

var springScene = document.getElementById("videoPreview");

function startPreview() {
    console.log("hovered")
    springScene.play();
}

function stopPreview() {
    springScene.pause();
}

