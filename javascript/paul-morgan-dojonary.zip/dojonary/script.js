function hide(element) {
    element.remove();
}
    
function turnoff(element) {
    element.innerText = "Log Off";
} 